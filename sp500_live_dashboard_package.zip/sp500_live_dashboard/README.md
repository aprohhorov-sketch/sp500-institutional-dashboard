# S&P 500 Institutional Market Dashboard

A portable single-page dashboard for S&P 500 valuation, earnings, market breadth, macro-financial conditions and bull/base/bear scenario analysis. The previous research report is included as `previous_institutional_report.pdf` and linked from the dashboard header.

## Recommended: run it locally

1. Extract the ZIP package.
2. Open a terminal in the `sp500_live_dashboard` folder.
3. Run:

   ```bash
   python -m http.server 8000
   ```

4. Visit http://localhost:8000 in a modern browser.
5. Click **Data settings**, add your own free FRED API key, and click **Save settings & refresh**.
6. The dashboard refreshes every 15 minutes while the page is open by default. Change this interval in **Data settings**.

You can also open `index.html` directly. If your browser blocks cross-origin requests or browser storage for local files, use the local-server method above. The TradingView ticker tape and data feeds require an internet connection.

## Free FRED API key

Get a personal key from: https://fred.stlouisfed.org/docs/api/api_key.html. The dashboard stores the key in the browser's local storage for the site origin and sends requests directly from that browser to FRED. The key is not embedded in the HTML file.

## What refreshes automatically

With a FRED API key configured, the page requests the latest available observations and historical series for:

- `SP500`: official S&P 500 daily close
- `DGS10`: 10-year nominal Treasury yield
- `DFII10`: 10-year TIPS real yield
- `BAMLH0A0HYM2`: US high-yield option-adjusted spread
- `NFCI`: Chicago Fed National Financial Conditions Index
- `DTWEXBGS`: broad nominal US dollar index
- `DCOILBRENTEU`: Brent crude oil price
- `VIXCLS`: CBOE VIX close
- `CPIAUCSL`: CPI index (year-over-year inflation calculated from the series)
- `UNRATE`: unemployment rate

The embedded TradingView ticker tape may display live or delayed quotes depending on exchange feeds and data licensing. FRED series update on their own schedules: refreshing the page does not imply that every source has published a new observation.

## What remains a dated research snapshot

Forward P/E, CAPE, historical valuation anchors and analyst-consensus estimates are stored as a dated snapshot because reliable public browser feeds for those institutional figures are not guaranteed. These values are editable in **Data settings** and saved only in the current browser. Update the figures from the cited provider when new data is published.

## Publishing it as a website

The dashboard is a static website and can be hosted on a static web host. Upload `index.html` and `previous_institutional_report.pdf` to the same site root; the dashboard will then link to the PDF. The ZIP includes both files and this README. The API key is entered in the browser settings and is not part of the published source files.

## Privacy and licensing

- API keys are stored in browser storage, not in the HTML file or a server. They are transmitted to the source provider from your browser when a request runs. Do not commit keys to a public repository.
- This is client-side only; it does not run scheduled cloud refreshes, refresh while the page is closed, or send push notifications.
- For a public deployment, confirm each provider's embedding, redistribution and market-data licensing terms. Do not expose personal credentials in source control.
- The dashboard is for research and monitoring, not personalised investment advice.
